// Elías Esquivel | eliasuna@gmail.com
// Stateside Lunch & Learn 7 Feb, 2019

// Inspired by https://marcosantadev.com/solid-principles-applied-swift/
