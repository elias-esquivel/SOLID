import UIKit

// Open closed
enum ViewType {
    case languages
    case passports
    case cities
}

class CustomView: UIView {
    var icon: UIImageView!
    var title: UILabel!
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    public func setup(type: ViewType) {
        switch type {
        case .cities:
            icon.image = UIImage(named: "cityImage")
            title.text = "Cities"
        case .languages:
            icon.image = UIImage(named: "languageImage")
            title.text = "Languages"
        case .passports:
            icon.image = UIImage(named: "iconImage")
            title.text = "Passports"
        }
    }
}
