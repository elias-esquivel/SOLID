//
//  SingleResponsability.swift
//
//
//  Created by Elias Esquivel on 2/6/19.
//
//  Help:
//    THERE SHOULD NEVER BE MORE THAN ONE REASON FOR A CLASS TO CHANGE.

import UIKit

class CustomTexField: UITextField {
    func updateErrorVisibility(isVisible: Bool) {
        //displayError
    }
}

extension CustomTexField: UITextFieldDelegate {
    func textFieldDidEndEditing(_ textField: UITextField) {
        guard let text = textField.text else {
            updateErrorVisibility(isVisible: true)
            return
        }
        
        if text.isEmpty ||
            text.count < 5 ||
            (text.contains("@") && text.contains(".com")) {
            updateErrorVisibility(isVisible: true)
        }
    }
}
