//
//  Interface Segregation.swift
//
//
//  Created by Elias Esquivel on 2/6/19.
//
//  Help
//    A. HIGH LEVEL MODULES SHOULD NOT DEPEND UPON LOW LEVEL MODULES. BOTH SHOULD DEPEND UPON ABSTRACTIONS.
//    B. ABSTRACTIONS SHOULD NOT DEPEND UPON DETAILS. DETAILS SHOULD DEPEND UPON ABSTRACTIONS.
//

import UIKit

struct ProductResponseModel {
    let productName: String
    let flags: [String]
    let images: [UIImage]
}

class ProductViewController {
    let productViewer = ProductViewer()
    let productFlagsView = ProductFlagsView()
    
    public func setup(responseModel: ProductResponseModel) {
        productViewer.setup(images: responseModel.images, productName: responseModel.productName)
        productFlagsView.setup(flags: responseModel.flags.joined(separator: "*"))
    }
}

class ProductViewer {
    var images: [UIImage]!
    var productNameLabel: UILabel!
    
    func setup(images: [UIImage], productName: String) {
        self.images = images
        productNameLabel.text = productName
    }
}

class ProductFlagsView {
    var flagsLabel: UILabel!
    
    func setup(flags: String) {
        flagsLabel.text = flags
    }
}

//protocol ProductViewPresentable {
//    var name: String { get }
//    var flags: [String] { get }
//    var images: [UIImage] { get }
//}


