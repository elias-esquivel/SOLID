//
//  OpenClose.swift
//
//
//  Created by Elias Esquivel on 2/6/19.
//
//  Help:
//    SOFTWARE ENTITIES (CLASSES, MODULES, FUNCTIONS, ETC.) SHOULD BE OPEN FOR EXTENSION, BUT CLOSED FOR MODIFICATION.

import UIKit

enum ViewType {
    case languages
    case passports
    case cities
}

class CustomView: UIView {
    var icon: UIImageView!
    var title: UILabel!
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    public func setup(type: ViewType) {
        switch type {
        case .cities:
            icon.image = UIImage(named: "cityImage")
            title.text = "Cities"
        case .languages:
            icon.image = UIImage(named: "languageImage")
            title.text = "Languages"
        case .passports:
            icon.image = UIImage(named: "iconImage")
            title.text = "Passports"
        }
    }
}

