//
//  SingleResponsabilitySolved.swift
//
//
//  Created by Elias Esquivel on 2/6/19.
//
//  Help:
//    THERE SHOULD NEVER BE MORE THAN ONE REASON FOR A CLASS TO CHANGE.

import UIKit

//class CustomTexField: UITextField {
//    func updateErrorVisibility(isVisible: Bool) {
//        //displayError
//    }
//}
//
//extension CustomTexField: UITextFieldDelegate {
//    func textFieldDidEndEditing(_ textField: UITextField) {
//        updateErrorVisibility(isVisible: TextValidator.isValidMail(textField.text))
//    }
//}
//
//struct TextValidator {
//    static func isValidMail(_ string: String?) -> Bool {
//        guard let string = string else {
//            return false
//        }
//        return !string.isEmpty && string.contains("@") && string.contains(".com")
//    }
//}
