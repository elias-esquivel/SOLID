//
//  OpenCloseSolved.swift
//
//
//  Created by Elias Esquivel on 2/6/19.
//
//  Help:
//    SOFTWARE ENTITIES (CLASSES, MODULES, FUNCTIONS, ETC.) SHOULD BE OPEN FOR EXTENSION, BUT CLOSED FOR MODIFICATION.

import UIKit

//class CustomView: UIView {
//    var icon: UIImageView!
//    var title: UILabel!
//    
//    required init?(coder aDecoder: NSCoder) {
//        super.init(coder: aDecoder)
//    }
//    
//    public func setup(presentableItem: CustomViewPresentable) {
//        icon.image = presentableItem.image
//        title.text = presentableItem.title
//    }
//}
//
//struct CustomViewPresentable {
//    let image: UIImage
//    let title: String
//}
