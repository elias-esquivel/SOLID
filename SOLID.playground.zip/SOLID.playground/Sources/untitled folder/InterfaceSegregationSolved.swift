//
//  InterfaceSegregationSolved.swift
//
//
//  Created by Elias Esquivel on 2/6/19.
//
//  Help
//    CLIENTS SHOULD NOT BE FORCED TO DEPEND UPON INTERFACES THAT THEY DO NOT USE.
//

//protocol GestureTapProtocol {
//    func didTap(_ button: UIButton)
//}
//
//protocol GestureLongPressProtocol {
//    func didLongPress(_ button: UIButton)
//}
//
//protocol GestureDoublePressProtocol {
//    func didLongPress(_ button: UIButton)
//}
//
//class CustomButton1: GestureTapProtocol {
//    func performTapAction() {
//        print("tapped")
//    }
//    
//    func didTap(_ button: UIButton) {
//        performTapAction()
//    }
//}
//
//class CustomButton2: GestureLongPressProtocol {
//    func performTapAction() {
//        print("tapped")
//    }
//    
//    func didLongPress(_ button: UIButton) {
//        performTapAction()
//    }
//}
