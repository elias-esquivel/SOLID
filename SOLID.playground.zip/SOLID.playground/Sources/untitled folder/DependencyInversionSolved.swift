//
//  DependencyInversionSolved.swift
//
//
//  Created by Elias Esquivel on 2/6/19.
//
//  Help
//    A. HIGH LEVEL MODULES SHOULD NOT DEPEND UPON LOW LEVEL MODULES. BOTH SHOULD DEPEND UPON ABSTRACTIONS.
//    B. ABSTRACTIONS SHOULD NOT DEPEND UPON DETAILS. DETAILS SHOULD DEPEND UPON ABSTRACTIONS.
//

//import UIKit
//
//protocol ProductViewPresentable {
//    var name: String { get }
//    var flagsValue: String { get }
//    var imagesValue: [UIImage] { get }
//}
//
//struct ProductResponseModel {
//    let productName: String
//    let flags: [String]
//    let images: [UIImage]
//}
//
//extension ProductResponseModel: ProductViewPresentable {
//    var name: String {
//        return productName
//    }
//    
//    var flagsValue: String {
//        return flags.joined(separator: "*")
//    }
//    
//    var imagesValue: [UIImage] {
//        return self.images
//    }
//}
//
//class ProductViewController {
//    let productViewer = ProductViewer()
//    let productFlagsView = ProductFlagsView()
//    
//    public func setup(presentableItem: ProductViewPresentable) {
//        productViewer.setup(images: presentableItem.imagesValue, productName: presentableItem.name)
//        productFlagsView.setup(flags: presentableItem.flagsValue)
//    }
//}
//
//class ProductViewer {
//    var images: [UIImage]!
//    var productNameLabel: UILabel!
//    
//    func setup(images: [UIImage], productName: String) {
//        self.images = images
//        productNameLabel.text = productName
//    }
//}
//
//class ProductFlagsView {
//    var flagsLabel: UILabel!
//    
//    func setup(flags: String) {
//        flagsLabel.text = flags
//    }
//}
