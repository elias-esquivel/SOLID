//
//  LiskovSolved.swift
//
//
//  Created by Elias Esquivel on 2/6/19.
//
//  Help
//    FUNCTIONS THAT USE POINTERS OR REFERENCES TO BASE CLASSES MUST BE ABLE TO USE OBJECTS OF DERIVED CLASSES WITHOUT KNOWING IT
//  Importart!!
//    Use Composition over Inheritance

import Foundation

//struct ProductResponse {
//    let productId: String
//    let skuId: String
//}
//
//protocol ProductsRetriever {
//    func getAllProducts() -> [ProductResponse]
//}
//
//class NetworkAPI: ProductsRetriever {
//    private var products: [ProductResponse] {
//        let p1 = ProductResponse(productId: "P123", skuId: "S324234")
//        let p2 = ProductResponse(productId: "P125", skuId: "S324234")
//        let p3 = ProductResponse(productId: "P126", skuId: "S324274")
//        let p4 = ProductResponse(productId: "P124", skuId: "S324254")
//        
//        return [p1, p2, p3, p4]
//    }
//    
//    func getAllProducts() -> [ProductResponse] {
//        return products
//    }
//}
//
//class CoreDataAPI: ProductsRetriever {
//    private var products: [ProductResponse] {
//        let p1 = ProductResponse(productId: "P123", skuId: "S324234")
//        let p2 = ProductResponse(productId: "P125", skuId: "S324234")
//        let p3 = ProductResponse(productId: "P126", skuId: "S324274")
//        let p4 = ProductResponse(productId: "P124", skuId: "S324254")
//        
//        return [p1, p2, p3, p4]
//    }
//    
//    func getAllProducts() -> [ProductResponse] {
//        return products
//    }
//}
//
//class ProductViewModel {
//    func load() {
//        retrieveData(productRetriever: productRetriever)
//    }
//    
//    var productRetriever: ProductsRetriever {
//        if true {
//            return NetworkAPI()
//        }
//        return CoreDataAPI()
//    }
//    
//    func retrieveData(productRetriever: ProductsRetriever) {
//        productRetriever.getAllProducts()
//    }
//}







