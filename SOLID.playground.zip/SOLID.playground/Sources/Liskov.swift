//
//  Liskov.swift
//
//
//  Created by Elias Esquivel on 2/6/19.
//
//  Help
//    FUNCTIONS THAT USE POINTERS OR REFERENCES TO BASE CLASSES MUST BE ABLE TO USE OBJECTS OF DERIVED CLASSES WITHOUT KNOWING IT
//  Importart!!
//    Use Composition over Inheritance

import Foundation

struct ProductResponse {
    let productId: String
    let skuId: String
}

class DataAPI {
    public func getAllProducts() -> [ProductResponse] {
        return [ProductResponse]()
    }
}

class NetworkAPI: DataAPI {
    private var products: [ProductResponse] {
        let p1 = ProductResponse(productId: "P123", skuId: "S324234")
        let p2 = ProductResponse(productId: "P125", skuId: "S324234")
        let p3 = ProductResponse(productId: "P126", skuId: "S324274")
        let p4 = ProductResponse(productId: "P124", skuId: "S324254")
        
        return [p1, p2, p3, p4]
    }
    
    override func getAllProducts() -> [ProductResponse] {
        return products
    }
}

class CoreDataAPI: DataAPI {
    private var products: [ProductResponse] {
        let p1 = ProductResponse(productId: "P123", skuId: "S324234")
        let p2 = ProductResponse(productId: "P125", skuId: "S324234")
        let p3 = ProductResponse(productId: "P126", skuId: "S324274")
        let p4 = ProductResponse(productId: "P124", skuId: "S324254")
        
        return [p1, p2, p3, p4]
    }
    
    override func getAllProducts() -> [ProductResponse] {
        return products.filter { $0.skuId == "S324234" }
    }
}
