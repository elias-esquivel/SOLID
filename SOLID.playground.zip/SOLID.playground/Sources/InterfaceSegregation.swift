//
//  Interface Segregation.swift
//
//
//  Created by Elias Esquivel on 2/6/19.
//
//  Help
//    CLIENTS SHOULD NOT BE FORCED TO DEPEND UPON INTERFACES THAT THEY DO NOT USE.
//

import UIKit

protocol GestureProtocol {
    func didTap()
    func didDoubleTap()
    func didLongPress()
}

class CustomButton: GestureProtocol {
    func performTapAction() {
        print("tapped")
    }
    
    func didTap() {
        performTapAction()
    }
    
    func didDoubleTap() {
        //do nothing
    }
    
    func didLongPress() {
        //do nothing
    }
}
